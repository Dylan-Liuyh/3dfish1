# -*- encoding=utf8 -*-
__author__ = "dylan"
import sys
import os
import codecs
import traceback
sys.path.append(os.path.abspath(__file__))
from airtest.core.api import *
from poco.drivers.unity3d import UnityPoco
import sys
root_path = os.path.abspath(__file__)
root_path = '/'.join(root_path.split('/')[:-3])
sys.path.append(root_path)
from common.common_func import *

class Testpack():
    def __init__(self):
        super().__init__()
    def test_pack(self):
        common_click_by_node_name(poco("btnPack"))
        poco("btnPack").click([1,0.5])
        poco(texture="common_effect_select").click()
        poco("btnRight").click()
        wait(Template(r"tpl1656424869426.png", record_pos=(0.021, -0.015), resolution=(2400, 1080)))
        poco("TextPro").click()
        poco("btnLeft").click()
        wait(Template(r"tpl1656424916128.png", record_pos=(0.022, -0.012), resolution=(2400, 1080)))
        poco("TextPro").click()
        poco("btnItem").click()
        touch(Template(r"tpl1656425327527.png", record_pos=(0.242, -0.003), resolution=(2400, 1080)))
        poco("Text").click()
        wait(Template(r"tpl1656425352092.png", record_pos=(0.022, -0.01), resolution=(2400, 1080)))
        poco("TextPro").click()
        poco("btnClose").click()
        common_try_to_go_to_hall()
        
if __name__=='__main__':
    poco = UnityPoco
    #stop_app("com.tuyoo.fish3d.official")  # 清除3D捕鱼大作战的全部数据
    #start_app("com.tuyoo.fish3d.official")
    common_restart_app()
    from poco.drivers.unity3d import UnityPoco
    poco = UnityPoco()
    #wait(Template(r"tpl1656552714834.png", record_pos=(0.033, 0.128), resolution=(2400, 1080)))
    #poco("btnPlay").click()
    #touch(Template(r"tpl1656553013445.png", record_pos=(0.022, 0.114), resolution=(2400, 1080)))
    #from poco.drivers.unity3d import UnityPoco
    #poco = UnityPoco()
    try:
        close_activity = poco("ui_popup").child("Canvas").child("activity").child("btn").child(name="btnClose")
        close_activity.click()
    except:
        pass
a = Testpack()
a.test_pack()

