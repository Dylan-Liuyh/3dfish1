import io
import os.path
import jinja2

from airtest.core.api import *
from airtest.report.report import LogToHtml
from airtest.utils.compat import script_dir_name
from poco.drivers.unity3d import UnityPoco
from airtest.core.android import Android

android=Android()
appPackageList = android.list_app(third_only=True)
PACKAGE_NAME_LIST = ["com.tuyoo.fish3d.official"]
CHANGE_SERVER_PACKAGE_NAME = "com.tuyoo.fish3d.official"
auto_setup(__file__)

def common_click_by_node_name(obj, wait_time=0):
    try:
        for item in obj:
            item.click()
            if wait_time > 0:
                sleep(wait_time)
    except:
        print("Exception!!! common_func common_click_by_node_name:%s" % obj)


def common_click_by_image_name(poco, name, wait_time=0, area=[0.5, 0.5]):
    try:
        for item in poco(texture=name):
            item.click(area)
            if wait_time > 0:
                sleep(wait_time)
    except:
        print("Exception!!! common_func common_click_by_image_name:%s" % name)


def common_click_by_obj(obj, tip="", wait_time=0.5):
    assert_equal(obj.exists(), True, tip or "")
    obj.click()
    sleep(wait_time)


def common_click_by_text_content(poco, text_content, wait_time=0):
    try:
        for item in poco(text=text_content):
            item.click()
            if wait_time > 0:
                sleep(wait_time)
    except:
        print("Exception!!! common_func common_click_by_text_content:%s" % text_content)


def common_exists_by_obj(obj):
    return obj.exists()

'''

这个不急，孩子实在是太累了，先挪过来一个远征的占个位置，慢慢写


def common_close_popups_hit_your_face_if_need():
    print("aaabbb_common_close_popups_hit_your_face_if_need")
    # 暴力穷举，通过节点的标题进行穷举，尽量实现在进入大厅后可以将弹窗关闭
    while True:
        poco = UnityPoco()
        close_activity = (
            poco("ui_popup")
            .child("Canvas")
            .child("activity")
            .child("btn")
            .child(name="btnClose")
        )
        if poco("ui_popup").child("Canvas").child("activity").child("btn").child(name="btnClose").exists():

            common_click_by_node_name(poco, "close_activity", 1)
        elif poco("ui_btn_close").exists():
            common_click_by_node_name(poco, "ui_btn_close", 1)
        elif poco("ui_closebtn").exists():
            common_click_by_node_name(poco, "ui_closebtn", 1)
        elif poco("ui_btnClose").exists():
            common_click_by_node_name(poco, "ui_btnClose", 1)
        if (
            poco("TipDialog").exists() and poco("ui_button_close").exists()
        ):  # 优先处理各种"挽留"性质的通用弹窗，不然会一直点遮罩后面的弹窗的关闭按钮
            common_click_by_node_name(poco, "ui_button_close", 1)
        if poco(texture="common_btn_close").exists():
            common_click_by_image_name(poco, "common_btn_close", 1)
            print(
                'aaabbb_common_close_popups_one_by_one_if_need common_click_by_image_name(poco, "common_btn_close", 1)'
            )
        elif poco(texture="com_btn_close_blue").exists():
            common_click_by_image_name(poco, "com_btn_close_blue", 1)
            print(
                'aaabbb_common_close_popups_one_by_one_if_need common_click_by_image_name(poco, "com_btn_close_blue", 1)'
            )
        elif poco(texture="finch_btn_close").exists():
            common_click_by_image_name(poco, "finch_btn_close", 1)
            print(
                'jjjjjj_common_close_popups_one_by_one_if_need common_click_by_image_name(poco, "finch_btn_close", 1)'
            )
        elif poco(texture="Housekeeper_Close").exists():
            common_click_by_image_name(poco, "Housekeeper_Close", 1)
            print(
                'jjjjjj_common_close_popups_one_by_one_if_need common_click_by_image_name(poco, "Housekeeper_Close", 1)'
            )
        elif poco(texture="theMasters_closeBtn").exists():
            common_click_by_image_name(poco, "theMasters_closeBtn", 1)
            print(
                'jjjjjj_common_close_popups_one_by_one_if_need common_click_by_image_name(poco, "theMasters_closeBtn", 1)'
            )
        elif poco(texture="zylb_close").exists():
            common_click_by_image_name(poco, "zylb_close", 1)
            print(
                'jjjjjj_common_close_popups_one_by_one_if_need common_click_by_image_name(poco, "zylb_close", 1)'
            )
        elif poco(texture="newbieSign_imageX").exists():
            common_click_by_image_name(poco, "newbieSign_imageX", 1)
            print(
                'jjjjjj_common_close_popups_one_by_one_if_need common_click_by_image_name(poco, "newbieSign_imageX", 1)'
            )
        elif poco("ui_btn_back").exists():
            # 带有左上角返回箭头的二级UI的处理
            common_click_by_node_name(poco, "ui_btn_back", 1)
            print(
                'jjjjjj_common_close_popups_one_by_one_if_need common_click_by_node_name(poco, 、"ui_btn_back", 1)'
            )
        elif poco("ui_hall_guide_new").exists():
            common_click_by_node_name(poco, "ui_top", 1)
        else:
            print("jjjjjj_common_close_popups_one_by_one_if_need finish!")
            sleep(1)
            break
'''


def common_test_poco_is_connect():
    print(" ababab_common_test_poco_is_connect")
    poco=UnityPoco()
    try:
        poco("popup").exists()
        return True
    except:
        return False

def common_restart_app():
    print("aaabbb_common_restart_app")
    sleep(5)
    stop_app(PACKAGE_NAME)
    sleep(5)
    start_app(CHANGE_SERVER_PACKAGE_NAME)
    wait(Template(r"tpl1656552714834.png", record_pos=(0.033, 0.128), resolution=(2400, 1080)))
    # poco("btnPlay").click()
    touch(Template(r"tpl1656553013445.png", record_pos=(0.022, 0.114), resolution=(2400, 1080)))
    sleep(3)


